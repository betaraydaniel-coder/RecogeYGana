# 📝 Mis Notas — Aplicación Android

## Descripción
**Mis Notas** es una aplicación Android de bloc de notas personal desarrollada en **Kotlin** siguiendo las mejores prácticas de Android moderno. Permite crear, visualizar, editar y eliminar notas con almacenamiento local persistente mediante SQLite, y consulta una API externa para mostrar una frase motivacional diaria.

---

## ✨ Funcionalidades (más allá de los requisitos mínimos)

### Requisitos cubiertos ✅
- ✅ Proyecto Android Studio con estructura estándar (manifest, res, kotlin, gradle)
- ✅ Código 100% en **Kotlin** con variables, funciones, condicionales y listas
- ✅ **3 Activities**: `MainActivity`, `CrearNotaActivity`, `DetalleNotaActivity`
- ✅ Navegación con **Intents** y paso de datos entre Activities
- ✅ UI con archivos XML: `RecyclerView`, `FloatingActionButton`, `EditText`
- ✅ **SQLite** para almacenamiento persistente con operaciones CRUD completas
- ✅ Eliminación con **swipe** (deslizamiento izquierda/derecha)
- ✅ API externa: ZenQuotes.io para frases motivacionales
- ✅ Código comentado y nombres descriptivos

### Características adicionales 🚀
- 🎨 **Temas de color**: 8 colores disponibles para personalizar cada nota
- ⭐ **Notas favoritas**: marcar/desmarcar con icono de estrella
- 🔍 **Búsqueda en tiempo real**: filtra por título o contenido
- ↩️ **Deshacer eliminación**: Snackbar con opción de revertir el borrado
- 📅 **Fechas inteligentes**: muestra "Hoy", "Ayer" o fecha completa
- 🌙 **Modo oscuro**: soporte completo con tema Material Design 3
- 📱 **Material You**: diseño con Material Design 3 / Material 3
- 🔄 **Confirmación de salida**: alerta si hay cambios sin guardar
- 💾 **Patrón Repository**: separación de capas de datos y UI
- 🧵 **Coroutines**: operaciones de red y BD en hilos secundarios (sin bloqueo de UI)
- 📌 **Notas de ejemplo**: primer uso con 3 notas de bienvenida pre-instaladas
- 🔁 **Frase offline**: frases locales si no hay conexión a Internet

---

## 🏗️ Arquitectura del Proyecto

```
app/src/main/java/com/misnotas/app/
├── activities/
│   ├── MainActivity.kt          ← Pantalla principal con lista de notas
│   ├── CrearNotaActivity.kt     ← Crear/editar una nota
│   └── DetalleNotaActivity.kt  ← Ver nota completa (Activity 3 extra)
├── adapters/
│   ├── NotasAdapter.kt          ← RecyclerView adapter con DiffUtil
│   └── ColorAdapter.kt          ← Selector de colores para notas
├── database/
│   ├── NotasDatabaseHelper.kt   ← SQLiteOpenHelper con CRUD completo
│   └── NotasRepository.kt       ← Patrón Repository para abstracción de datos
├── models/
│   ├── Nota.kt                  ← Data class de la nota
│   └── FraseMotivacional.kt    ← Model para respuesta de la API
├── network/
│   ├── FrasesApiService.kt      ← Interfaz Retrofit (endpoints)
│   └── RetrofitClient.kt        ← Singleton del cliente HTTP
└── utils/
    └── Extensions.kt            ← Extensiones Kotlin reutilizables
```

---

## 🛠️ Tecnologías Usadas

| Tecnología | Versión | Uso |
|---|---|---|
| Kotlin | 1.9.22 | Lenguaje principal |
| Android SDK | API 24–34 | Plataforma |
| Material Design 3 | 1.11.0 | Componentes UI |
| SQLite | Nativo | Almacenamiento local |
| Retrofit 2 | 2.9.0 | Cliente HTTP para la API |
| OkHttp | 4.12.0 | Interceptor de red |
| Gson | (con Retrofit) | Serialización JSON |
| Coroutines | 1.7.3 | Programación asíncrona |
| View Binding | - | Acceso seguro a vistas |
| RecyclerView + DiffUtil | 1.3.2 | Lista eficiente con animaciones |

---

## 🌐 API Externa

**ZenQuotes.io** — API gratuita, sin API key requerida.

- **Endpoint**: `GET https://zenquotes.io/api/random`
- **Respuesta**: `[{"q": "frase", "a": "autor"}]`
- **Fallback**: Si no hay conexión, se muestra una frase local aleatoria.

---

## 📦 Cómo abrir y compilar

1. Abre **Android Studio** (Electric Eel o superior recomendado)
2. Selecciona **File → Open** y navega a la carpeta `MisNotas`
3. Espera a que Gradle sincronice las dependencias
4. Ejecuta en emulador o dispositivo con **Run → Run 'app'** (Shift+F10)
5. Para generar el APK: **Build → Build Bundle(s)/APK(s) → Build APK(s)**

### Requisitos del sistema
- Android Studio Hedgehog (2023.1) o superior
- JDK 17+
- Android SDK con API 34 instalado
- Emulador o dispositivo con Android 7.0+ (API 24)

---

## 👨‍💻 Notas de desarrollo

- Se usa el patrón **Singleton** en `NotasDatabaseHelper` para evitar conflictos de concurrencia en SQLite.
- Las operaciones de base de datos se ejecutan en `Dispatchers.IO` usando **coroutines** para no bloquear el hilo principal.
- El adaptador usa `ListAdapter` con `DiffUtil` para animar cambios en la lista de forma eficiente.
- Se implementó el patrón **Repository** para facilitar pruebas unitarias y mantener separación de responsabilidades.

---

*Desarrollado como proyecto académico — Programación Móvil*
