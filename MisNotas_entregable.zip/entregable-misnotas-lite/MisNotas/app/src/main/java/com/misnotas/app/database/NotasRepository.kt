package com.misnotas.app.database

import android.content.Context
import com.misnotas.app.models.Nota

/**
 * Repositorio de notas: capa de abstracción entre los ViewModels y la fuente de datos (SQLite).
 *
 * Siguiendo el patrón Repository, centraliza todas las operaciones de datos
 * para que las Activities y ViewModels no interactúen directamente con la BD.
 */
class NotasRepository(context: Context) {

    private val dbHelper = NotasDatabaseHelper.obtenerInstancia(context)

    /** Recupera todas las notas de la base de datos. */
    fun obtenerTodasLasNotas(): List<Nota> = dbHelper.obtenerTodasLasNotas()

    /** Recupera una nota específica por su ID. */
    fun obtenerNotaPorId(id: Long): Nota? = dbHelper.obtenerNotaPorId(id)

    /** Guarda una nota nueva y retorna el ID asignado. */
    fun guardarNota(nota: Nota): Long = dbHelper.insertarNota(nota)

    /** Actualiza una nota existente. */
    fun actualizarNota(nota: Nota): Boolean = dbHelper.actualizarNota(nota) > 0

    /** Elimina una nota por su ID. */
    fun eliminarNota(id: Long): Boolean = dbHelper.eliminarNota(id)

    /** Alterna el estado de favorita de una nota. */
    fun alternarFavorita(id: Long, esFavorita: Boolean) = dbHelper.alternarFavorita(id, esFavorita)

    /** Retorna el número total de notas. */
    fun contarNotas(): Int = dbHelper.contarNotas()

    /**
     * Busca notas cuyo título o contenido contenga el texto dado (búsqueda local).
     */
    fun buscarNotas(consulta: String): List<Nota> {
        if (consulta.isBlank()) return obtenerTodasLasNotas()
        val consultaMinusculas = consulta.lowercase()
        return obtenerTodasLasNotas().filter { nota ->
            nota.titulo.lowercase().contains(consultaMinusculas) ||
                    nota.contenido.lowercase().contains(consultaMinusculas)
        }
    }
}
