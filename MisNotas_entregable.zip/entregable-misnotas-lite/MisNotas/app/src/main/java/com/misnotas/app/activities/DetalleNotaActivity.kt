package com.misnotas.app.activities

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.misnotas.app.R
import com.misnotas.app.database.NotasRepository
import com.misnotas.app.databinding.ActivityDetalleNotaBinding
import com.misnotas.app.models.Nota
import com.misnotas.app.utils.aFechaLegible
import com.misnotas.app.utils.mostrarToast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Activity de detalle: muestra el contenido completo de una nota.
 *
 * Permite al usuario:
 * - Leer el contenido completo de la nota
 * - Navegar a [CrearNotaActivity] para editarla
 * - Eliminar la nota desde el menú
 * - Ver la fecha de creación y última modificación
 */
class DetalleNotaActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "DetalleNotaActivity"
        /** Extra con el ID de la nota a mostrar (Long). Obligatorio. */
        const val EXTRA_NOTA_ID = "extra_nota_id"
        private const val CODIGO_EDICION = 2001
    }

    private lateinit var binding: ActivityDetalleNotaBinding
    private lateinit var repositorio: NotasRepository

    // Nota actualmente mostrada
    private var notaActual: Nota? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDetalleNotaBinding.inflate(layoutInflater)
        setContentView(binding.root)

        repositorio = NotasRepository(this)

        // Configurar Toolbar
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = ""

        // Cargar la nota desde el ID recibido por Intent
        val idNota = intent.getLongExtra(EXTRA_NOTA_ID, -1L)
        if (idNota != -1L) {
            cargarNota(idNota)
        } else {
            mostrarToast("Error: nota no encontrada")
            finish()
        }

        // Botón flotante de edición
        binding.fabEditar.setOnClickListener {
            notaActual?.let { nota -> abrirEdicion(nota) }
        }
    }

    override fun onResume() {
        super.onResume()
        // Recargar en caso de que se haya editado
        notaActual?.let { cargarNota(it.id) }
    }

    /**
     * Carga la nota desde la base de datos y actualiza la UI.
     */
    private fun cargarNota(id: Long) {
        lifecycleScope.launch {
            val nota = withContext(Dispatchers.IO) {
                repositorio.obtenerNotaPorId(id)
            }

            if (nota != null) {
                notaActual = nota
                mostrarNota(nota)
            } else {
                mostrarToast("Nota no encontrada")
                finish()
            }
        }
    }

    /**
     * Actualiza todas las vistas con los datos de la nota.
     */
    private fun mostrarNota(nota: Nota) {
        binding.textTituloDetalle.text = nota.titulo.ifBlank { "Sin título" }
        binding.textContenidoDetalle.text = nota.contenido
        binding.textFechaCreacion.text = "Creada: ${nota.fechaCreacion.aFechaLegible()}"
        binding.textFechaModificacion.text = "Modificada: ${nota.fechaModificacion.aFechaLegible()}"

        // Aplicar color de fondo de la nota
        try {
            binding.layoutDetalleContenido.setBackgroundColor(Color.parseColor(nota.color))
        } catch (e: Exception) {
            Log.e(TAG, "Color inválido: ${nota.color}")
        }

        // Icono de favorita en el título
        if (nota.esFavorita) {
            binding.textTituloDetalle.setCompoundDrawablesWithIntrinsicBounds(
                0, 0, android.R.drawable.star_big_on, 0
            )
        }
    }

    /**
     * Navega a [CrearNotaActivity] en modo edición.
     */
    private fun abrirEdicion(nota: Nota) {
        val intent = Intent(this, CrearNotaActivity::class.java).apply {
            putExtra(CrearNotaActivity.EXTRA_NOTA_ID, nota.id)
        }
        startActivityForResult(intent, CODIGO_EDICION)
    }

    /**
     * Elimina la nota actual con confirmación.
     */
    private fun eliminarNota() {
        notaActual?.let { nota ->
            AlertDialog.Builder(this)
                .setTitle("Eliminar nota")
                .setMessage("¿Estás seguro de que deseas eliminar esta nota?")
                .setPositiveButton("Eliminar") { _, _ ->
                    lifecycleScope.launch {
                        val eliminada = withContext(Dispatchers.IO) {
                            repositorio.eliminarNota(nota.id)
                        }
                        if (eliminada) {
                            mostrarToast("Nota eliminada")
                            setResult(RESULT_OK)
                            finish()
                        } else {
                            mostrarToast("Error al eliminar")
                        }
                    }
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_detalle_nota, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            R.id.action_editar -> {
                notaActual?.let { abrirEdicion(it) }
                true
            }
            R.id.action_eliminar -> {
                eliminarNota()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    @Deprecated("Usar registerForActivityResult")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CODIGO_EDICION && resultCode == RESULT_OK) {
            setResult(RESULT_OK) // Propagar el resultado a MainActivity
        }
    }
}
