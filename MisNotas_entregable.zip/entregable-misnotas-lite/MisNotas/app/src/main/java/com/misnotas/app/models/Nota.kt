package com.misnotas.app.models

/**
 * Modelo de datos que representa una nota en la aplicación.
 *
 * @property id Identificador único generado por la base de datos (0 = nota nueva sin guardar)
 * @property titulo Título corto de la nota
 * @property contenido Cuerpo o contenido detallado de la nota
 * @property fechaCreacion Timestamp de creación en milisegundos (System.currentTimeMillis)
 * @property fechaModificacion Timestamp de la última modificación
 * @property color Color de fondo de la tarjeta (guardado como string hexadecimal, p.ej. "#FFF9C4")
 * @property esFavorita Indica si el usuario marcó esta nota como favorita
 */
data class Nota(
    val id: Long = 0,
    val titulo: String,
    val contenido: String,
    val fechaCreacion: Long = System.currentTimeMillis(),
    val fechaModificacion: Long = System.currentTimeMillis(),
    val color: String = "#FFFFFF",
    val esFavorita: Boolean = false
) {
    /**
     * Retorna un resumen del contenido, limitado a [maxCaracteres] caracteres.
     * Útil para mostrar una vista previa en la lista de notas.
     */
    fun resumenContenido(maxCaracteres: Int = 100): String {
        return if (contenido.length > maxCaracteres) {
            contenido.take(maxCaracteres) + "..."
        } else {
            contenido
        }
    }

    /**
     * Indica si la nota está vacía (sin título ni contenido significativo).
     */
    fun estaVacia(): Boolean = titulo.isBlank() && contenido.isBlank()
}
