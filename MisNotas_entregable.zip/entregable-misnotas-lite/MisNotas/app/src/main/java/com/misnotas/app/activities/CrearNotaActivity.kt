package com.misnotas.app.activities

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.misnotas.app.R
import com.misnotas.app.adapters.ColorAdapter
import com.misnotas.app.database.NotasRepository
import com.misnotas.app.databinding.ActivityCrearNotaBinding
import com.misnotas.app.models.Nota
import com.misnotas.app.utils.mostrarToast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Activity para crear una nota nueva o editar una existente.
 *
 * Cuando se lanza con [EXTRA_NOTA_ID], carga la nota existente para edición.
 * Sin ese extra, crea una nota nueva.
 *
 * Al guardar, regresa a [MainActivity] con [RESULT_OK] para que recargue la lista.
 */
class CrearNotaActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "CrearNotaActivity"
        /** Extra para pasar el ID de la nota a editar (Long). No incluir para crear. */
        const val EXTRA_NOTA_ID = "extra_nota_id"
        const val ID_NOTA_NUEVA = -1L
    }

    private lateinit var binding: ActivityCrearNotaBinding
    private lateinit var repositorio: NotasRepository

    // Nota que se está editando (null si es nueva)
    private var notaActual: Nota? = null

    // Color seleccionado por el usuario para la nota
    private var colorSeleccionado: String = "#FFFFFF"

    // Indica si hay cambios sin guardar
    private var hayCambiosSinGuardar = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityCrearNotaBinding.inflate(layoutInflater)
        setContentView(binding.root)

        repositorio = NotasRepository(this)

        // Configurar Toolbar con botón de regreso
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Determinar si estamos en modo creación o edición
        val idNota = intent.getLongExtra(EXTRA_NOTA_ID, ID_NOTA_NUEVA)
        if (idNota != ID_NOTA_NUEVA) {
            cargarNotaExistente(idNota)
            supportActionBar?.title = "Editar nota"
        } else {
            supportActionBar?.title = "Nueva nota"
        }

        configurarSelectorDeColor()
        configurarDetectorDeCambios()
    }

    // ══════════════════════════════════════════════════════════════════════════════
    // CONFIGURACIÓN DE LA UI
    // ══════════════════════════════════════════════════════════════════════════════

    /**
     * Carga una nota existente desde la BD y pre-llena los campos del formulario.
     */
    private fun cargarNotaExistente(id: Long) {
        lifecycleScope.launch {
            val nota = withContext(Dispatchers.IO) {
                repositorio.obtenerNotaPorId(id)
            }

            nota?.let {
                notaActual = it
                colorSeleccionado = it.color

                // Pre-llenar los campos
                binding.editTitulo.setText(it.titulo)
                binding.editContenido.setText(it.contenido)

                // Aplicar color de fondo
                actualizarColorFondo(it.color)
                Log.d(TAG, "Nota cargada para edición: ${it.id}")
            }
        }
    }

    /**
     * Configura el RecyclerView horizontal con el selector de colores para la nota.
     */
    private fun configurarSelectorDeColor() {
        val adaptadorColor = ColorAdapter(colorSeleccionado) { colorElegido ->
            colorSeleccionado = colorElegido
            actualizarColorFondo(colorElegido)
        }

        binding.recyclerColores.apply {
            layoutManager = LinearLayoutManager(
                this@CrearNotaActivity,
                LinearLayoutManager.HORIZONTAL,
                false
            )
            adapter = adaptadorColor
        }
    }

    /**
     * Actualiza el color de fondo del formulario para previsualizar el color elegido.
     */
    private fun actualizarColorFondo(colorHex: String) {
        try {
            binding.layoutContenedor.setBackgroundColor(Color.parseColor(colorHex))
        } catch (e: Exception) {
            Log.e(TAG, "Color inválido: $colorHex", e)
        }
    }

    /**
     * Configura los TextWatchers para detectar cambios en los campos y marcar
     * la nota como modificada (para alertar al usuario si intenta salir sin guardar).
     */
    private fun configurarDetectorDeCambios() {
        val detector = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                hayCambiosSinGuardar = true
            }
            override fun afterTextChanged(s: Editable?) {}
        }

        binding.editTitulo.addTextChangedListener(detector)
        binding.editContenido.addTextChangedListener(detector)
    }

    // ══════════════════════════════════════════════════════════════════════════════
    // LÓGICA DE GUARDADO
    // ══════════════════════════════════════════════════════════════════════════════

    /**
     * Valida y guarda la nota (creación o actualización según el contexto).
     * Muestra errores inline si los campos requeridos están vacíos.
     */
    private fun guardarNota() {
        val titulo = binding.editTitulo.text.toString().trim()
        val contenido = binding.editContenido.text.toString().trim()

        // Validación: al menos uno de los dos campos debe tener contenido
        if (titulo.isBlank() && contenido.isBlank()) {
            binding.editTitulo.error = "Escribe un título o contenido para la nota"
            binding.editTitulo.requestFocus()
            return
        }

        // Construir el objeto Nota a guardar
        val nota = if (notaActual != null) {
            // Edición: conservar ID y fecha de creación original
            notaActual!!.copy(
                titulo = titulo.ifBlank { "Sin título" },
                contenido = contenido,
                fechaModificacion = System.currentTimeMillis(),
                color = colorSeleccionado
            )
        } else {
            // Creación: nueva nota con timestamps actuales
            Nota(
                titulo = titulo.ifBlank { "Sin título" },
                contenido = contenido,
                color = colorSeleccionado
            )
        }

        lifecycleScope.launch {
            val exito = withContext(Dispatchers.IO) {
                if (nota.id == 0L) {
                    repositorio.guardarNota(nota) > 0
                } else {
                    repositorio.actualizarNota(nota)
                }
            }

            if (exito) {
                hayCambiosSinGuardar = false
                mostrarToast(if (nota.id == 0L) "Nota guardada ✓" else "Nota actualizada ✓")
                setResult(RESULT_OK, Intent().apply {
                    putExtra("nota_guardada", true)
                })
                finish()
            } else {
                mostrarToast("Error al guardar la nota")
                Log.e(TAG, "Error al guardar/actualizar nota")
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════════════════
    // MANEJO DEL MENÚ Y NAVEGACIÓN
    // ══════════════════════════════════════════════════════════════════════════════

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_crear_nota, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                manejarRegreso()
                true
            }
            R.id.action_guardar -> {
                guardarNota()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onBackPressed() {
        manejarRegreso()
    }

    /**
     * Maneja el regreso del usuario. Si hay cambios sin guardar, muestra un diálogo
     * de confirmación para evitar pérdida de datos accidental.
     */
    private fun manejarRegreso() {
        if (hayCambiosSinGuardar) {
            AlertDialog.Builder(this)
                .setTitle("Cambios sin guardar")
                .setMessage("¿Deseas descartar los cambios?")
                .setPositiveButton("Descartar") { _, _ ->
                    setResult(RESULT_CANCELED)
                    finish()
                }
                .setNegativeButton("Seguir editando", null)
                .setNeutralButton("Guardar") { _, _ -> guardarNota() }
                .show()
        } else {
            setResult(RESULT_CANCELED)
            finish()
        }
    }
}
