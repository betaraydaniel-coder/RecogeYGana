package com.misnotas.app.network

import com.misnotas.app.models.FraseMotivacional
import retrofit2.Response
import retrofit2.http.GET

/**
 * Interfaz de Retrofit que define los endpoints de la API de frases motivacionales.
 * Usamos ZenQuotes (https://zenquotes.io/api/) que es gratuita y no requiere API key.
 */
interface FrasesApiService {

    /**
     * Obtiene una frase motivacional aleatoria del día.
     * Endpoint: GET /api/random
     * Respuesta: Lista con un único objeto de frase.
     */
    @GET("api/random")
    suspend fun obtenerFraseAleatoria(): Response<List<FraseMotivacional>>
}
