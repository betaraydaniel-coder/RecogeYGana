package com.misnotas.app.adapters

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.misnotas.app.utils.COLORES_NOTA

/**
 * Adaptador para el selector de colores en la pantalla de crear/editar nota.
 * Muestra círculos de colores que el usuario puede seleccionar.
 *
 * @param alSeleccionarColor Callback con el color seleccionado en formato hex
 */
class ColorAdapter(
    private val colorSeleccionado: String,
    private val alSeleccionarColor: (String) -> Unit
) : RecyclerView.Adapter<ColorAdapter.ColorViewHolder>() {

    private var indiceSeleccionado = COLORES_NOTA.indexOf(colorSeleccionado).coerceAtLeast(0)

    inner class ColorViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun enlazar(colorHex: String, estaSeleccionado: Boolean) {
            // Crear un círculo con el color correspondiente
            val drawable = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor(colorHex))
                setStroke(
                    if (estaSeleccionado) 6 else 2,
                    if (estaSeleccionado) Color.parseColor("#1976D2") else Color.parseColor("#CCCCCC")
                )
            }
            itemView.background = drawable
            itemView.setOnClickListener {
                val indiceAnterior = indiceSeleccionado
                indiceSeleccionado = adapterPosition
                notifyItemChanged(indiceAnterior)
                notifyItemChanged(indiceSeleccionado)
                alSeleccionarColor(colorHex)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ColorViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(android.R.layout.simple_list_item_1, parent, false)
        view.layoutParams = ViewGroup.LayoutParams(80, 80)
        return ColorViewHolder(view)
    }

    override fun onBindViewHolder(holder: ColorViewHolder, position: Int) {
        holder.enlazar(COLORES_NOTA[position], position == indiceSeleccionado)
    }

    override fun getItemCount() = COLORES_NOTA.size
}
