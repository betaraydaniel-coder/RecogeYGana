package com.misnotas.app.utils

import android.content.Context
import android.graphics.Color
import android.view.View
import android.widget.Toast
import com.google.android.material.snackbar.Snackbar
import java.text.SimpleDateFormat
import java.util.*

/**
 * Extensiones y utilidades generales de la aplicación.
 * Agrupa funciones reutilizables para evitar duplicación de código.
 */

// ── Formateo de fechas ────────────────────────────────────────────────────────

/**
 * Convierte un timestamp en milisegundos a una cadena de texto legible.
 * Ejemplo: 1704067200000 → "01 ene 2024, 10:30"
 */
fun Long.aFechaLegible(): String {
    val formato = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
    return formato.format(Date(this))
}

/**
 * Convierte un timestamp a formato corto para la lista de notas.
 * Ejemplo: hoy → "10:30", ayer → "Ayer", otro día → "01/01/24"
 */
fun Long.aFechaCorta(): String {
    val ahora = Calendar.getInstance()
    val fecha = Calendar.getInstance().apply { timeInMillis = this@aFechaCorta }

    return when {
        // Mismo día: mostrar hora
        ahora.get(Calendar.DAY_OF_YEAR) == fecha.get(Calendar.DAY_OF_YEAR) &&
                ahora.get(Calendar.YEAR) == fecha.get(Calendar.YEAR) -> {
            SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(this))
        }
        // Día anterior: mostrar "Ayer"
        ahora.get(Calendar.DAY_OF_YEAR) - fecha.get(Calendar.DAY_OF_YEAR) == 1 &&
                ahora.get(Calendar.YEAR) == fecha.get(Calendar.YEAR) -> "Ayer"
        // Mismo año: mostrar día y mes
        ahora.get(Calendar.YEAR) == fecha.get(Calendar.YEAR) -> {
            SimpleDateFormat("dd MMM", Locale.getDefault()).format(Date(this))
        }
        // Año diferente: mostrar fecha completa corta
        else -> SimpleDateFormat("dd/MM/yy", Locale.getDefault()).format(Date(this))
    }
}

// ── UI Helpers ────────────────────────────────────────────────────────────────

/** Muestra un Toast corto. */
fun Context.mostrarToast(mensaje: String) {
    Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show()
}

/** Muestra un Snackbar informativo en la vista dada. */
fun View.mostrarSnackbar(
    mensaje: String,
    duracion: Int = Snackbar.LENGTH_SHORT,
    accion: String? = null,
    alHacerClick: (() -> Unit)? = null
) {
    val snackbar = Snackbar.make(this, mensaje, duracion)
    if (accion != null && alHacerClick != null) {
        snackbar.setAction(accion) { alHacerClick() }
    }
    snackbar.show()
}

/** Hace visible una View. */
fun View.mostrar() {
    visibility = View.VISIBLE
}

/** Oculta una View (pero mantiene su espacio). */
fun View.ocultar() {
    visibility = View.INVISIBLE
}

/** Elimina una View del layout (no ocupa espacio). */
fun View.eliminar() {
    visibility = View.GONE
}

// ── Colores de notas ──────────────────────────────────────────────────────────

/**
 * Lista de colores disponibles para las notas.
 * Colores pastel que se ven bien en modo claro y oscuro.
 */
val COLORES_NOTA = listOf(
    "#FFFFFF", // Blanco (defecto)
    "#E3F2FD", // Azul claro
    "#F3E5F5", // Morado claro
    "#E8F5E9", // Verde claro
    "#FFF9C4", // Amarillo claro
    "#FFE0B2", // Naranja claro
    "#FFCDD2", // Rojo claro
    "#E0F7FA"  // Cian claro
)

/**
 * Determina si un color de fondo requiere texto oscuro o claro para legibilidad.
 * @param colorHex Color en formato hexadecimal (#RRGGBB)
 * @return true si el texto debe ser oscuro, false si debe ser claro
 */
fun requiereTextoOscuro(colorHex: String): Boolean {
    return try {
        val color = Color.parseColor(colorHex)
        val luminancia = (0.299 * Color.red(color) +
                0.587 * Color.green(color) +
                0.114 * Color.blue(color)) / 255
        luminancia > 0.5
    } catch (e: Exception) {
        true // Por defecto, texto oscuro
    }
}
