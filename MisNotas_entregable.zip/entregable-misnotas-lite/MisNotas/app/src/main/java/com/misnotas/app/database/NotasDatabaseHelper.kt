package com.misnotas.app.database

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import com.misnotas.app.models.Nota

/**
 * Helper de base de datos SQLite para gestionar el almacenamiento persistente de notas.
 *
 * Implementa el patrón Singleton para garantizar una sola instancia de la base de datos
 * durante el ciclo de vida de la aplicación, evitando conflictos de escritura concurrente.
 */
class NotasDatabaseHelper private constructor(context: Context) :
    SQLiteOpenHelper(context.applicationContext, NOMBRE_BD, null, VERSION_BD) {

    companion object {
        // ── Metadatos de la base de datos ──────────────────────────────────────────
        private const val NOMBRE_BD = "mis_notas.db"
        private const val VERSION_BD = 1

        // ── Tabla de notas ──────────────────────────────────────────────────────────
        const val TABLA_NOTAS = "notas"
        const val COLUMNA_ID = "_id"
        const val COLUMNA_TITULO = "titulo"
        const val COLUMNA_CONTENIDO = "contenido"
        const val COLUMNA_FECHA_CREACION = "fecha_creacion"
        const val COLUMNA_FECHA_MODIFICACION = "fecha_modificacion"
        const val COLUMNA_COLOR = "color"
        const val COLUMNA_ES_FAVORITA = "es_favorita"

        private const val TAG = "NotasDatabaseHelper"

        // Singleton thread-safe
        @Volatile
        private var instancia: NotasDatabaseHelper? = null

        fun obtenerInstancia(context: Context): NotasDatabaseHelper {
            return instancia ?: synchronized(this) {
                instancia ?: NotasDatabaseHelper(context).also { instancia = it }
            }
        }
    }

    // ── Sentencia SQL para crear la tabla ────────────────────────────────────────
    private val sentenciaCrearTabla = """
        CREATE TABLE $TABLA_NOTAS (
            $COLUMNA_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            $COLUMNA_TITULO TEXT NOT NULL,
            $COLUMNA_CONTENIDO TEXT NOT NULL,
            $COLUMNA_FECHA_CREACION INTEGER NOT NULL,
            $COLUMNA_FECHA_MODIFICACION INTEGER NOT NULL,
            $COLUMNA_COLOR TEXT DEFAULT '#FFFFFF',
            $COLUMNA_ES_FAVORITA INTEGER DEFAULT 0
        )
    """.trimIndent()

    /**
     * Se ejecuta la primera vez que se crea la base de datos.
     * Crea la tabla de notas y opcionalmente inserta datos de ejemplo.
     */
    override fun onCreate(db: SQLiteDatabase) {
        Log.d(TAG, "Creando base de datos versión $VERSION_BD")
        db.execSQL(sentenciaCrearTabla)
        insertarNotasDeEjemplo(db)
    }

    /**
     * Se ejecuta cuando la versión de la BD aumenta (migraciones).
     * Actualmente elimina y recrea la tabla; en producción se harían migraciones granulares.
     */
    override fun onUpgrade(db: SQLiteDatabase, versionAnterior: Int, versionNueva: Int) {
        Log.d(TAG, "Actualizando BD de versión $versionAnterior a $versionNueva")
        db.execSQL("DROP TABLE IF EXISTS $TABLA_NOTAS")
        onCreate(db)
    }

    /**
     * Habilita las claves foráneas al abrir la BD (buena práctica aunque aquí no se usen).
     */
    override fun onOpen(db: SQLiteDatabase) {
        super.onOpen(db)
        if (!db.isReadOnly) {
            db.execSQL("PRAGMA foreign_keys = ON;")
        }
    }

    // ══════════════════════════════════════════════════════════════════════════════
    // OPERACIONES CRUD
    // ══════════════════════════════════════════════════════════════════════════════

    /**
     * Inserta una nueva nota en la base de datos.
     * @return El ID generado para la nota, o -1 si ocurrió un error.
     */
    fun insertarNota(nota: Nota): Long {
        val db = writableDatabase
        val valores = notaAContentValues(nota)
        val idGenerado = db.insert(TABLA_NOTAS, null, valores)
        Log.d(TAG, "Nota insertada con ID: $idGenerado")
        return idGenerado
    }

    /**
     * Obtiene todas las notas ordenadas por fecha de modificación (más reciente primero).
     * @return Lista de notas; lista vacía si no hay notas guardadas.
     */
    fun obtenerTodasLasNotas(): List<Nota> {
        val listaNotas = mutableListOf<Nota>()
        val db = readableDatabase

        val cursor = db.query(
            TABLA_NOTAS,
            null, // Seleccionar todas las columnas
            null, // Sin filtro WHERE
            null,
            null,
            null,
            "$COLUMNA_FECHA_MODIFICACION DESC" // Ordenar por más reciente
        )

        // Recorrer el cursor y convertir cada fila en un objeto Nota
        cursor.use { c ->
            while (c.moveToNext()) {
                listaNotas.add(cursorANota(c))
            }
        }

        Log.d(TAG, "Notas recuperadas: ${listaNotas.size}")
        return listaNotas
    }

    /**
     * Obtiene una nota específica por su ID.
     * @return La nota encontrada, o null si no existe.
     */
    fun obtenerNotaPorId(id: Long): Nota? {
        val db = readableDatabase
        val cursor = db.query(
            TABLA_NOTAS,
            null,
            "$COLUMNA_ID = ?",
            arrayOf(id.toString()),
            null, null, null
        )

        return cursor.use { c ->
            if (c.moveToFirst()) cursorANota(c) else null
        }
    }

    /**
     * Actualiza los datos de una nota existente.
     * @return Número de filas afectadas (1 si fue exitoso, 0 si no se encontró la nota).
     */
    fun actualizarNota(nota: Nota): Int {
        val db = writableDatabase
        val valores = notaAContentValues(nota).apply {
            // Actualizar la fecha de modificación al momento actual
            put(COLUMNA_FECHA_MODIFICACION, System.currentTimeMillis())
        }

        val filasAfectadas = db.update(
            TABLA_NOTAS,
            valores,
            "$COLUMNA_ID = ?",
            arrayOf(nota.id.toString())
        )
        Log.d(TAG, "Nota ${nota.id} actualizada. Filas afectadas: $filasAfectadas")
        return filasAfectadas
    }

    /**
     * Elimina una nota de la base de datos por su ID.
     * @return true si la eliminación fue exitosa, false en caso contrario.
     */
    fun eliminarNota(id: Long): Boolean {
        val db = writableDatabase
        val filasEliminadas = db.delete(
            TABLA_NOTAS,
            "$COLUMNA_ID = ?",
            arrayOf(id.toString())
        )
        Log.d(TAG, "Nota $id eliminada. Filas afectadas: $filasEliminadas")
        return filasEliminadas > 0
    }

    /**
     * Alterna el estado de favorita de una nota.
     * @return true si ahora es favorita, false si dejó de serlo.
     */
    fun alternarFavorita(id: Long, esFavorita: Boolean): Boolean {
        val db = writableDatabase
        val valores = ContentValues().apply {
            put(COLUMNA_ES_FAVORITA, if (esFavorita) 1 else 0)
        }
        db.update(TABLA_NOTAS, valores, "$COLUMNA_ID = ?", arrayOf(id.toString()))
        return esFavorita
    }

    /**
     * Retorna el número total de notas guardadas.
     */
    fun contarNotas(): Int {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT COUNT(*) FROM $TABLA_NOTAS", null)
        return cursor.use { c ->
            if (c.moveToFirst()) c.getInt(0) else 0
        }
    }

    // ══════════════════════════════════════════════════════════════════════════════
    // MÉTODOS AUXILIARES PRIVADOS
    // ══════════════════════════════════════════════════════════════════════════════

    /**
     * Convierte un objeto Nota en ContentValues para operaciones de BD.
     */
    private fun notaAContentValues(nota: Nota): ContentValues {
        return ContentValues().apply {
            put(COLUMNA_TITULO, nota.titulo)
            put(COLUMNA_CONTENIDO, nota.contenido)
            put(COLUMNA_FECHA_CREACION, nota.fechaCreacion)
            put(COLUMNA_FECHA_MODIFICACION, nota.fechaModificacion)
            put(COLUMNA_COLOR, nota.color)
            put(COLUMNA_ES_FAVORITA, if (nota.esFavorita) 1 else 0)
        }
    }

    /**
     * Convierte una fila del Cursor en un objeto Nota.
     */
    private fun cursorANota(cursor: android.database.Cursor): Nota {
        return Nota(
            id = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMNA_ID)),
            titulo = cursor.getString(cursor.getColumnIndexOrThrow(COLUMNA_TITULO)),
            contenido = cursor.getString(cursor.getColumnIndexOrThrow(COLUMNA_CONTENIDO)),
            fechaCreacion = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMNA_FECHA_CREACION)),
            fechaModificacion = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMNA_FECHA_MODIFICACION)),
            color = cursor.getString(cursor.getColumnIndexOrThrow(COLUMNA_COLOR)),
            esFavorita = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMNA_ES_FAVORITA)) == 1
        )
    }

    /**
     * Inserta notas de ejemplo para que la app no aparezca vacía la primera vez.
     */
    private fun insertarNotasDeEjemplo(db: SQLiteDatabase) {
        val notasEjemplo = listOf(
            ContentValues().apply {
                put(COLUMNA_TITULO, "¡Bienvenido a Mis Notas! 👋")
                put(COLUMNA_CONTENIDO, "Esta es tu primera nota. Puedes crear, editar y eliminar notas fácilmente.\n\n• Toca el botón + para crear una nueva nota\n• Desliza una nota hacia la izquierda para eliminarla\n• Toca el ❤️ para marcarla como favorita\n• Toca la nota para ver su contenido completo")
                put(COLUMNA_FECHA_CREACION, System.currentTimeMillis())
                put(COLUMNA_FECHA_MODIFICACION, System.currentTimeMillis())
                put(COLUMNA_COLOR, "#E3F2FD")
                put(COLUMNA_ES_FAVORITA, 1)
            },
            ContentValues().apply {
                put(COLUMNA_TITULO, "Ideas para el proyecto")
                put(COLUMNA_CONTENIDO, "- Rediseñar la pantalla principal\n- Agregar búsqueda de notas\n- Exportar notas a PDF\n- Sincronización en la nube\n- Widgets para la pantalla de inicio")
                put(COLUMNA_FECHA_CREACION, System.currentTimeMillis() - 86400000)
                put(COLUMNA_FECHA_MODIFICACION, System.currentTimeMillis() - 86400000)
                put(COLUMNA_COLOR, "#F3E5F5")
                put(COLUMNA_ES_FAVORITA, 0)
            },
            ContentValues().apply {
                put(COLUMNA_TITULO, "Lista de compras")
                put(COLUMNA_CONTENIDO, "□ Leche\n□ Pan integral\n□ Huevos\n□ Frutas de temporada\n□ Arroz\n□ Frijoles\n□ Aceite de oliva")
                put(COLUMNA_FECHA_CREACION, System.currentTimeMillis() - 172800000)
                put(COLUMNA_FECHA_MODIFICACION, System.currentTimeMillis() - 172800000)
                put(COLUMNA_COLOR, "#E8F5E9")
                put(COLUMNA_ES_FAVORITA, 0)
            }
        )

        notasEjemplo.forEach { valores ->
            db.insert(TABLA_NOTAS, null, valores)
        }
        Log.d(TAG, "Notas de ejemplo insertadas: ${notasEjemplo.size}")
    }
}
