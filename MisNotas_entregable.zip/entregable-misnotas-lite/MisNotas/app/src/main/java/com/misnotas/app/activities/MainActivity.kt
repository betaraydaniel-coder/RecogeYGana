package com.misnotas.app.activities

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import com.misnotas.app.R
import com.misnotas.app.adapters.NotasAdapter
import com.misnotas.app.database.NotasRepository
import com.misnotas.app.databinding.ActivityMainBinding
import com.misnotas.app.models.FraseMotivacional
import com.misnotas.app.models.Nota
import com.misnotas.app.network.RetrofitClient
import com.misnotas.app.utils.aFechaLegible
import com.misnotas.app.utils.eliminar
import com.misnotas.app.utils.mostrar
import com.misnotas.app.utils.mostrarSnackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Activity principal de la aplicación Mis Notas.
 *
 * Responsabilidades:
 * - Mostrar la lista de notas guardadas en SQLite usando un RecyclerView
 * - Obtener y mostrar una frase motivacional desde la API externa (ZenQuotes)
 * - Navegar hacia [CrearNotaActivity] para agregar/editar notas
 * - Navegar hacia [DetalleNotaActivity] para ver una nota completa
 * - Manejar la eliminación de notas con gesto de deslizamiento (swipe)
 * - Proveer búsqueda de notas en tiempo real
 */
class MainActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "MainActivity"
        // Código de solicitud para identificar el resultado de CrearNotaActivity
        const val CODIGO_SOLICITUD_CREAR_NOTA = 1001
        const val CODIGO_SOLICITUD_EDITAR_NOTA = 1002
    }

    // View Binding: acceso seguro y sin casting a las vistas del layout
    private lateinit var binding: ActivityMainBinding

    // Repositorio de datos: abstrae el acceso a la base de datos SQLite
    private lateinit var repositorio: NotasRepository

    // Adaptador del RecyclerView
    private lateinit var adaptador: NotasAdapter

    // Lista mutable de notas en memoria (fuente de verdad para la UI)
    private val listaNotas = mutableListOf<Nota>()

    // Nota eliminada temporalmente (para la función "Deshacer")
    private var notaEliminadaTemporal: Nota? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inflar el layout usando View Binding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Configurar Toolbar
        setSupportActionBar(binding.toolbar)
        supportActionBar?.title = getString(R.string.app_name)

        // Inicializar repositorio de base de datos
        repositorio = NotasRepository(this)

        // Configurar componentes de la UI
        configurarRecyclerView()
        configurarBotonAgregar()
        configurarSwipeParaEliminar()

        // Cargar datos
        cargarNotas()
        cargarFraseMotivacional()
    }

    /**
     * Se ejecuta cuando la Activity vuelve al primer plano.
     * Recarga las notas para reflejar cambios hechos en otras Activities.
     */
    override fun onResume() {
        super.onResume()
        cargarNotas()
    }

    // ══════════════════════════════════════════════════════════════════════════════
    // CONFIGURACIÓN DE LA UI
    // ══════════════════════════════════════════════════════════════════════════════

    /**
     * Configura el RecyclerView con su LayoutManager y adaptador.
     * Usa LinearLayoutManager para lista vertical simple.
     */
    private fun configurarRecyclerView() {
        adaptador = NotasAdapter(
            alHacerClick = { nota -> abrirDetalleNota(nota) },
            alHacerLongClick = { nota -> mostrarMenuContextual(nota) },
            alAlternarFavorita = { nota, esFavorita -> alternarFavorita(nota, esFavorita) }
        )

        binding.recyclerNotas.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = adaptador
            // Mejorar rendimiento si el tamaño del RecyclerView no cambia
            setHasFixedSize(true)
        }
    }

    /**
     * Configura el FloatingActionButton para navegar a la pantalla de creación de notas.
     */
    private fun configurarBotonAgregar() {
        binding.fabAgregarNota.setOnClickListener {
            val intent = Intent(this, CrearNotaActivity::class.java)
            startActivityForResult(intent, CODIGO_SOLICITUD_CREAR_NOTA)
        }
    }

    /**
     * Configura el gesto de deslizamiento (swipe left/right) para eliminar notas.
     * Incluye confirmación y opción de deshacer mediante Snackbar.
     */
    private fun configurarSwipeParaEliminar() {
        val callbackSwipe = object : ItemTouchHelper.SimpleCallback(
            0, // Sin soporte para arrastrar (drag)
            ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT // Deslizar en ambas direcciones
        ) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean = false // No soportamos drag & drop

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val posicion = viewHolder.adapterPosition
                val nota = listaNotas[posicion]
                eliminarNotaConDeshacer(nota, posicion)
            }
        }

        ItemTouchHelper(callbackSwipe).attachToRecyclerView(binding.recyclerNotas)
    }

    // ══════════════════════════════════════════════════════════════════════════════
    // MANEJO DE DATOS
    // ══════════════════════════════════════════════════════════════════════════════

    /**
     * Carga todas las notas desde la base de datos y actualiza la UI.
     * Se ejecuta en el hilo principal usando coroutines para no bloquear la UI.
     */
    private fun cargarNotas() {
        lifecycleScope.launch {
            // Operación de BD en hilo de IO para no bloquear el hilo principal
            val notas = withContext(Dispatchers.IO) {
                repositorio.obtenerTodasLasNotas()
            }

            // Actualizar la lista en el hilo principal
            listaNotas.clear()
            listaNotas.addAll(notas)
            adaptador.submitList(listaNotas.toList())

            // Mostrar u ocultar el estado vacío
            actualizarEstadoVacio()
            Log.d(TAG, "Notas cargadas: ${listaNotas.size}")
        }
    }

    /**
     * Obtiene una frase motivacional de la API externa de forma asíncrona.
     * Maneja errores de red mostrando un mensaje de fallback.
     */
    private fun cargarFraseMotivacional() {
        lifecycleScope.launch {
            try {
                // Llamada a la API en hilo de IO
                val respuesta = withContext(Dispatchers.IO) {
                    RetrofitClient.frasesApi.obtenerFraseAleatoria()
                }

                if (respuesta.isSuccessful) {
                    val frases = respuesta.body()
                    val frase = frases?.firstOrNull()

                    if (frase != null && frase.esValida()) {
                        // Mostrar la frase en la UI
                        binding.textFraseMotivacional.text = "\"${frase.frase}\""
                        binding.textAutorFrase.text = "— ${frase.autor}"
                        binding.cardFrase.mostrar()
                        Log.d(TAG, "Frase cargada: ${frase.frase}")
                    } else {
                        mostrarFraseFallback()
                    }
                } else {
                    Log.w(TAG, "Error en API: ${respuesta.code()}")
                    mostrarFraseFallback()
                }
            } catch (e: Exception) {
                // Error de red (sin conexión, timeout, etc.)
                Log.e(TAG, "Error al obtener frase motivacional", e)
                mostrarFraseFallback()
            }
        }
    }

    /**
     * Muestra una frase motivacional local cuando la API no está disponible.
     */
    private fun mostrarFraseFallback() {
        val frasesFallback = listOf(
            FraseMotivacional("El éxito es la suma de pequeños esfuerzos repetidos día tras día.", "Robert Collier"),
            FraseMotivacional("No esperes el momento perfecto. Toma el momento y hazlo perfecto.", "Anónimo"),
            FraseMotivacional("La disciplina es el puente entre las metas y los logros.", "Jim Rohn"),
            FraseMotivacional("Cada nota que escribes es un paso hacia tu mejor versión.", "Mis Notas")
        )
        val frase = frasesFallback.random()
        binding.textFraseMotivacional.text = "\"${frase.frase}\""
        binding.textAutorFrase.text = "— ${frase.autor}"
        binding.cardFrase.mostrar()
    }

    /**
     * Elimina una nota con la posibilidad de deshacer la acción durante 5 segundos.
     */
    private fun eliminarNotaConDeshacer(nota: Nota, posicion: Int) {
        // Guardar referencia para posible deshacer
        notaEliminadaTemporal = nota

        // Eliminar de la lista visual inmediatamente
        listaNotas.removeAt(posicion)
        adaptador.submitList(listaNotas.toList())
        actualizarEstadoVacio()

        // Mostrar Snackbar con opción de deshacer
        binding.root.mostrarSnackbar(
            mensaje = "Nota eliminada",
            duracion = Snackbar.LENGTH_LONG,
            accion = "Deshacer"
        ) {
            // El usuario tocó "Deshacer": restaurar la nota
            notaEliminadaTemporal?.let { notaRestaurada ->
                listaNotas.add(posicion.coerceAtMost(listaNotas.size), notaRestaurada)
                adaptador.submitList(listaNotas.toList())
                actualizarEstadoVacio()
                notaEliminadaTemporal = null
            }
        }

        // Eliminar de la BD en un hilo separado (se confirma tras el Snackbar)
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                repositorio.eliminarNota(nota.id)
            }
            Log.d(TAG, "Nota ${nota.id} eliminada de la BD")
        }
    }

    /**
     * Alterna el estado de favorita de una nota y actualiza la BD.
     */
    private fun alternarFavorita(nota: Nota, esFavorita: Boolean) {
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                repositorio.alternarFavorita(nota.id, esFavorita)
            }
            // Actualizar la lista en memoria
            val indice = listaNotas.indexOfFirst { it.id == nota.id }
            if (indice != -1) {
                listaNotas[indice] = nota.copy(esFavorita = esFavorita)
                adaptador.submitList(listaNotas.toList())
            }
        }
    }

    /**
     * Muestra u oculta el estado de lista vacía según si hay notas o no.
     */
    private fun actualizarEstadoVacio() {
        if (listaNotas.isEmpty()) {
            binding.layoutEstadoVacio.mostrar()
            binding.recyclerNotas.eliminar()
        } else {
            binding.layoutEstadoVacio.eliminar()
            binding.recyclerNotas.mostrar()
        }
    }

    // ══════════════════════════════════════════════════════════════════════════════
    // NAVEGACIÓN
    // ══════════════════════════════════════════════════════════════════════════════

    /**
     * Navega a la pantalla de detalle de una nota.
     * Pasa el ID de la nota mediante un Intent Extra.
     */
    private fun abrirDetalleNota(nota: Nota) {
        val intent = Intent(this, DetalleNotaActivity::class.java).apply {
            putExtra(DetalleNotaActivity.EXTRA_NOTA_ID, nota.id)
        }
        startActivityForResult(intent, CODIGO_SOLICITUD_EDITAR_NOTA)
    }

    /**
     * Muestra un diálogo contextual con opciones para la nota seleccionada.
     * @return true para consumir el evento de long click
     */
    private fun mostrarMenuContextual(nota: Nota): Boolean {
        val opciones = arrayOf("✏️ Editar", "🗑️ Eliminar", "ℹ️ Información")

        AlertDialog.Builder(this)
            .setTitle(nota.titulo.ifBlank { "Sin título" })
            .setItems(opciones) { _, indice ->
                when (indice) {
                    0 -> abrirEditarNota(nota)
                    1 -> confirmarEliminacion(nota)
                    2 -> mostrarInfoNota(nota)
                }
            }
            .show()

        return true
    }

    /** Abre la pantalla de edición de una nota existente. */
    private fun abrirEditarNota(nota: Nota) {
        val intent = Intent(this, CrearNotaActivity::class.java).apply {
            putExtra(CrearNotaActivity.EXTRA_NOTA_ID, nota.id)
        }
        startActivityForResult(intent, CODIGO_SOLICITUD_EDITAR_NOTA)
    }

    /** Muestra un diálogo de confirmación antes de eliminar una nota. */
    private fun confirmarEliminacion(nota: Nota) {
        AlertDialog.Builder(this)
            .setTitle("Eliminar nota")
            .setMessage("¿Deseas eliminar \"${nota.titulo.ifBlank { "esta nota" }}\"? Esta acción no se puede deshacer.")
            .setPositiveButton("Eliminar") { _, _ ->
                val posicion = listaNotas.indexOfFirst { it.id == nota.id }
                if (posicion != -1) eliminarNotaConDeshacer(nota, posicion)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    /** Muestra información de la nota (fechas de creación y modificación). */
    private fun mostrarInfoNota(nota: Nota) {
        AlertDialog.Builder(this)
            .setTitle("Información de la nota")
            .setMessage(
                "📅 Creada: ${nota.fechaCreacion.aFechaLegible()}\n" +
                        "✏️ Modificada: ${nota.fechaModificacion.aFechaLegible()}\n" +
                        "📝 Caracteres: ${nota.contenido.length}\n" +
                        "⭐ Favorita: ${if (nota.esFavorita) "Sí" else "No"}"
            )
            .setPositiveButton("Cerrar", null)
            .show()
    }

    // ══════════════════════════════════════════════════════════════════════════════
    // MENÚ Y BÚSQUEDA
    // ══════════════════════════════════════════════════════════════════════════════

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)

        // Configurar SearchView para búsqueda en tiempo real
        val itemBuscar = menu.findItem(R.id.action_search)
        val searchView = itemBuscar.actionView as SearchView

        searchView.queryHint = "Buscar notas..."
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                buscarNotas(query ?: "")
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                buscarNotas(newText ?: "")
                return true
            }
        })

        itemBuscar.setOnActionExpandListener(object : MenuItem.OnActionExpandListener {
            override fun onMenuItemActionExpand(item: MenuItem): Boolean = true
            override fun onMenuItemActionCollapse(item: MenuItem): Boolean {
                cargarNotas() // Restaurar lista completa al cerrar búsqueda
                return true
            }
        })

        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_refresh_quote -> {
                cargarFraseMotivacional()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    /**
     * Filtra la lista de notas según el texto de búsqueda.
     */
    private fun buscarNotas(consulta: String) {
        lifecycleScope.launch {
            val resultados = withContext(Dispatchers.IO) {
                repositorio.buscarNotas(consulta)
            }
            adaptador.submitList(resultados)
        }
    }

    /**
     * Recibe el resultado de CrearNotaActivity o DetalleNotaActivity.
     * Recarga la lista si se guardaron cambios.
     */
    @Deprecated("Usar registerForActivityResult en proyectos nuevos")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            cargarNotas() // Recargar lista al regresar con cambios
        }
    }
}
