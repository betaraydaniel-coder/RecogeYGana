package com.misnotas.app.adapters

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.misnotas.app.databinding.ItemNotaBinding
import com.misnotas.app.models.Nota
import com.misnotas.app.utils.aFechaCorta

/**
 * Adaptador para el RecyclerView de la lista de notas.
 *
 * Utiliza [ListAdapter] con [DiffUtil] para animaciones eficientes al
 * agregar, eliminar o modificar notas sin redibujar toda la lista.
 *
 * @param alHacerClick Callback cuando el usuario toca una nota (para ver detalles)
 * @param alHacerLongClick Callback en pulsación larga (para selección o menú contextual)
 * @param alAlternarFavorita Callback cuando el usuario toca el icono de favorita
 */
class NotasAdapter(
    private val alHacerClick: (Nota) -> Unit,
    private val alHacerLongClick: (Nota) -> Boolean,
    private val alAlternarFavorita: (Nota, Boolean) -> Unit
) : ListAdapter<Nota, NotasAdapter.NotaViewHolder>(NotaDiffCallback()) {

    /**
     * ViewHolder que contiene las vistas de cada elemento de la lista.
     * Usa View Binding para acceso seguro y eficiente a las vistas.
     */
    inner class NotaViewHolder(private val binding: ItemNotaBinding) :
        RecyclerView.ViewHolder(binding.root) {

        /**
         * Enlaza los datos de una nota con las vistas del item.
         * @param nota La nota a mostrar en este ViewHolder
         */
        fun enlazar(nota: Nota) {
            with(binding) {
                // Contenido textual
                textTituloNota.text = nota.titulo.ifBlank { "Sin título" }
                textContenidoNota.text = nota.resumenContenido(120)
                textFechaNota.text = nota.fechaModificacion.aFechaCorta()

                // Color de fondo de la tarjeta
                try {
                    cardNota.setCardBackgroundColor(Color.parseColor(nota.color))
                } catch (e: Exception) {
                    cardNota.setCardBackgroundColor(Color.WHITE)
                }

                // Icono de favorita
                iconFavorita.setImageResource(
                    if (nota.esFavorita) android.R.drawable.star_big_on
                    else android.R.drawable.star_big_off
                )

                // Listeners de interacción
                root.setOnClickListener { alHacerClick(nota) }
                root.setOnLongClickListener { alHacerLongClick(nota) }
                iconFavorita.setOnClickListener {
                    alAlternarFavorita(nota, !nota.esFavorita)
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NotaViewHolder {
        val binding = ItemNotaBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return NotaViewHolder(binding)
    }

    override fun onBindViewHolder(holder: NotaViewHolder, position: Int) {
        holder.enlazar(getItem(position))
    }

    /**
     * DiffCallback para comparar notas y determinar qué cambió.
     * Permite que [ListAdapter] haga animaciones de cambios eficientemente.
     */
    class NotaDiffCallback : DiffUtil.ItemCallback<Nota>() {
        /** Compara identidad: dos notas son el mismo item si tienen el mismo ID. */
        override fun areItemsTheSame(itemViejo: Nota, itemNuevo: Nota): Boolean {
            return itemViejo.id == itemNuevo.id
        }

        /** Compara contenido: si todos los campos son iguales, no hay que redibujar. */
        override fun areContentsTheSame(itemViejo: Nota, itemNuevo: Nota): Boolean {
            return itemViejo == itemNuevo
        }
    }
}
