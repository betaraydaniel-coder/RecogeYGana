package com.misnotas.app.models

import com.google.gson.annotations.SerializedName

/**
 * Modelo que representa la respuesta de la API de frases motivacionales (ZenQuotes).
 * La API retorna una lista de objetos con los campos "q" (quote) y "a" (author).
 */
data class FraseMotivacional(
    @SerializedName("q") val frase: String = "",
    @SerializedName("a") val autor: String = ""
) {
    /**
     * Retorna la frase formateada para mostrar en la UI.
     */
    fun textoCompleto(): String = "\"$frase\"\n— $autor"

    /**
     * Verifica que la respuesta de la API sea válida.
     */
    fun esValida(): Boolean = frase.isNotBlank() && autor.isNotBlank()
}
