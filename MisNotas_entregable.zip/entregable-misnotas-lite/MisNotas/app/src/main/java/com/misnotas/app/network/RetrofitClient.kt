package com.misnotas.app.network

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/**
 * Cliente de Retrofit configurado como Singleton.
 * Centraliza la configuración de red para toda la aplicación.
 */
object RetrofitClient {

    // URL base de la API de ZenQuotes
    private const val BASE_URL = "https://zenquotes.io/"

    // Timeouts razonables para no bloquear la UI
    private const val TIMEOUT_SEGUNDOS = 15L

    /**
     * Instancia lazy del cliente HTTP con logging para depuración.
     * El nivel de logging se reduce a NONE en producción.
     */
    private val okHttpClient: OkHttpClient by lazy {
        val interceptorLogging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY // Cambiar a NONE en release
        }

        OkHttpClient.Builder()
            .addInterceptor(interceptorLogging)
            .connectTimeout(TIMEOUT_SEGUNDOS, TimeUnit.SECONDS)
            .readTimeout(TIMEOUT_SEGUNDOS, TimeUnit.SECONDS)
            .writeTimeout(TIMEOUT_SEGUNDOS, TimeUnit.SECONDS)
            .build()
    }

    /**
     * Instancia lazy de Retrofit con el cliente HTTP y el convertidor Gson.
     */
    private val retrofit: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    /**
     * Servicio de la API de frases motivacionales.
     * Usar esta propiedad para hacer llamadas a la API.
     */
    val frasesApi: FrasesApiService by lazy {
        retrofit.create(FrasesApiService::class.java)
    }
}
